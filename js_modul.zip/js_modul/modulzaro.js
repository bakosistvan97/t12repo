// 1. feladat
function KockaFelszin(a){
    let felszin=Number(6*(a*a))
    return felszin
}

// 2. feladat
function KockaTerfogat(a){
    let terfogat=Number(a*a*a)
    return terfogat
}

// 3. feladat
function PhErtek(vizsgaltErtek){
    let phertek=String("semleges")
    if (vizsgaltErtek<7){
        phertek=String("savas")
        return phertek
    }
    else if (vizsgaltErtek>7){
        phertek=String("lugos")
        return phertek
    }
    else{
        return phertek
    }
}

// 4. feladat
function ElsoNSzamOsszege(szamokMennyisege) {
    let szamokOsszege=Number(0)
    for (let i = 0; i <= szamokMennyisege; i++) {
        szamokOsszege= Number(szamokOsszege + i)
    }
    return szamokOsszege
}

// 5. feladat
function MaxParos(vizsgaltTomb){
    let legnagyobbParos=Number(0)
    for(let i=0; i<vizsgaltTomb.length; i++){
        if(vizsgaltTomb[i]%2==0 && vizsgaltTomb[i]>legnagyobbParos){
            legnagyobbParos=vizsgaltTomb[i]
        }
    }
    return legnagyobbParos
}

// 6. feladat
function MaganHangzokSzama(vizsgaltSzoveg){
    let maganhangzok=['a','á','e','é','i','í','o','ó','ö','ő','u','ú','ü','ű','A','Á','E','É','I','Í','O','Ó','Ö','Ő','U','Ú','Ü','Ű']
    let maganhangzokSzama=Number(0)
    for(let i=0; i<vizsgaltSzoveg.length; i++){
        	if(maganhangzok.includes(vizsgaltSzoveg[i])){
            maganhangzokSzama++;
        }
    }
    return maganhangzokSzama
}

// 7. feladat
function SzovegVisszafele(szoveg){
    let ujszoveg=String("");
    for(let i=szoveg.length - 1; i>=0; i--){
        ujszoveg+=szoveg[i];
    }
    return ujszoveg
}

// 8. feladat
//Vizsgált objektum:
const Dolgozok = [{
    nev: "Koaxk Ábel",
    kor: 23,
    fizetes: 400000,
    beosztas: "Rendszergazda"
},
{
    nev: "Zsíros B. Ödön",
    kor: 45,
    fizetes: 1200000,
    beosztas: "Ügyvezető Igazgató"
},
{
    nev: "Meg Győző",
    kor: 32,
    fizetes: 600000,
    beosztas: "Marketing Manager"
},
{
    nev: "Békés Csaba",
    kor: 63,
    fizetes: 180000,
    beosztas: "Takarító"
},
{
    nev: "Pofá Zoltán",
    kor: 25,
    fizetes: 300000,
    beosztas: "Biztonsági Őr"
},
{
    nev: "Fejet Lenke",
    kor: 22,
    fizetes: 220000,
    beosztas: "Irodai Titkár"
},
{
    nev: "Vak Cina",
    kor: 30,
    fizetes: 500000,
    beosztas: "Üzem Orvos"
}
];

function CegAtlagEletkor(vizsgaltObjektumTomb) {
    let atlagEletkor = Number();
    for (let i = 0; i < vizsgaltObjektumTomb.length; i++) {
        atlagEletkor += vizsgaltObjektumTomb[i].kor;
    }
    return Math.round( atlagEletkor / vizsgaltObjektumTomb.length);
}